#include "introGlutLib.h"

/******************************/
/* drawSpongebobArms Function */
/******************************/
void drawSpongebobArms(double Center_X, double Center_Y, double Height, unsigned long SkinColor)
{
   double Width = Height * 19 / 28;  
   SetPenColorHex(SkinColor);
   
      /* Left */
   DrawFillBox(Center_X - Width * 8 / 19,
               Center_Y - Height * 8.5 / 28,
               Center_X - Width * 7 / 19,
               Center_Y - Height * 3.5 / 28);
   
      /* Right */
   DrawFillBox(Center_X + Width * 8 / 19,
               Center_Y - Height * 8.5 / 28,
               Center_X + Width * 7 / 19,
               Center_Y - Height * 3.5 / 28);
}

/*********************************/
/* drawSpongebobSleeves Function */
/*********************************/
void drawSpongebobSleeves(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* Spongebob's Sleeves - White Surface */   
   SetPenColorHex(0xFFFFFF);
   
      /* Left */
   DrawFillTriangle(Center_X - Width * 7.5 / 19,
                    Center_Y - Height * .5 / 28,
                    Center_X - Width * 8.5 / 19,
                    Center_Y - Height * 3.5 / 28,
                    Center_X - Width * 6.5 / 19,
                    Center_Y - Height * 3.5 / 28);
                    
      /* Right */
   DrawFillTriangle(Center_X + Width * 7.5 / 19,
                    Center_Y - Height * .5 / 28,
                    Center_X + Width * 8.5 / 19,
                    Center_Y - Height * 3.5 / 28,
                    Center_X + Width * 6.5 / 19,
                    Center_Y - Height * 3.5 / 28);
   
   /* Spongebob's Sleeves - Black Outline */
   SetPenColorHex(0x000000);

      /* Left */
   DrawLine(Center_X - Width * 8.5 / 19,
            Center_Y - Height * 3.5 / 28,
            Center_X - Width * 7.5 / 19,
            Center_Y - Height * .5 / 28);
            
   DrawLine(Center_X - Width * 7.5 / 19,
            Center_Y - Height * .5 / 28,
            Center_X - Width * 6.5 / 19,
            Center_Y - Height * 3.5 / 28);
            
   DrawLine(Center_X - Width * 6.5 / 19,
            Center_Y - Height * 3.5 / 28,
            Center_X - Width * 8.5 / 19,
            Center_Y - Height * 3.5 / 28);            

      /* Right */
   DrawLine(Center_X + Width * 8.5 / 19,
            Center_Y - Height * 3.5 / 28,
            Center_X + Width * 7.5 / 19,
            Center_Y - Height * .5 / 28);
            
   DrawLine(Center_X + Width * 7.5 / 19,
            Center_Y - Height * .5 / 28,
            Center_X + Width * 6.5 / 19,
            Center_Y - Height * 3.5 / 28);
            
   DrawLine(Center_X + Width * 6.5 / 19,
            Center_Y - Height * 3.5 / 28,
            Center_X + Width * 8.5 / 19,
            Center_Y - Height * 3.5 / 28);    
}

/*****************************/
/* drawSpongebobTop Function */
/*****************************/
void drawSpongebobTop(double Center_X, double Center_Y, double Height, unsigned long SkinColor)
{
   double Width = Height * 19 / 28;     
   SetPenColorHex(SkinColor);		
   
   /* Rectangle */
   DrawFillBox(Center_X - Width * 7.5 / 19, 
               Center_Y - Height * 2.5 / 28,
               Center_X + Width * 7.5 / 19, 
               Center_Y + Height * 13.5 / 28);

   /* Triangles */
        
      /* Left */
   DrawFillTriangle(Center_X - Width * 7.5 / 19,
                    Center_Y - Height * 2.5 / 28,
                    Center_X - Width * 7.5 / 19,
                    Center_Y + Height * 13.5 / 28,
                    Center_X - Width * 9.5 / 19,
                    Center_Y + Height * 13.5 / 28);

      /* Right*/
   DrawFillTriangle(Center_X + Width * 7.5 / 19,
                    Center_Y - Height * 2.5 / 28,
                    Center_X + Width * 7.5 / 19,
                    Center_Y + Height * 13.5 / 28,
                    Center_X + Width * 9.5 / 19,
                    Center_Y + Height * 13.5 / 28);
}

/******************************/
/* drawSpongebobEyes Function */
/******************************/
void drawSpongebobEyes(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* White Circles */
   SetPenColorHex(0xFFFFFF);
   
      /* Left*/
   DrawFillCircle(Center_X - Width * 2.5 / 19,
                  Center_Y + Height * 7.5 / 28,
                  Width * 2.5 / 19);

      /* Right*/
   DrawFillCircle(Center_X + Width * 2.5 / 19,
                  Center_Y + Height * 7.5 / 28,
                  Width * 2.5 / 19);

   /* Black outlines of white circles */
   SetPenColorHex(0x000000);                     
   
      /* Left*/
   DrawCircle(Center_X - Width * 2.5 / 19,
              Center_Y + Height * 7.5 / 28,
              Width * 2.5 / 19);

      /* Right*/
   DrawCircle(Center_X + Width * 2.5 / 19,
              Center_Y + Height * 7.5 / 28,
              Width * 2.5 / 19);
                  
   /* Blue Circles */
   SetPenColorHex(0x6699FF);
   
      /* Left*/
   DrawFillCircle(Center_X - Width * 1.5 / 19,
                  Center_Y + Height * 7.5 / 28,
                  Width * 1 / 19);

      /* Right*/
   DrawFillCircle(Center_X + Width * 1.5 / 19,
                  Center_Y + Height * 7.5 / 28,
                  Width * 1 / 19);

   /* Black outlines of blue circles */
   SetPenColorHex(0x000000);                     
   
      /* Left*/
   DrawCircle(Center_X - Width * 1.5 / 19,
              Center_Y + Height * 7.5 / 28,
              Width * 1 / 19);

      /* Right*/
   DrawCircle(Center_X + Width * 1.5 / 19,
              Center_Y + Height * 7.5 / 28,
              Width * 1 / 19);                  

   /* Black Circles */
   SetPenColorHex(0x000000);
   
      /* Left*/
   DrawFillCircle(Center_X - Width * 1.5 / 19,
                  Center_Y + Height * 7.5 / 28,
                  Width * 1 / 38);

      /* Right*/
   DrawFillCircle(Center_X + Width * 1.5 / 19,
                  Center_Y + Height * 7.5 / 28,
                  Width * 1 / 38); 
}

/******************************/
/* drawSpongebobLips Function */
/******************************/
void drawSpongebobLips(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   SetPenColorHex(0x000000);
    
      /* Left segment */
   DrawLine(Center_X - Width * 5 / 19,
            Center_Y + Height * 5.5 / 28,
            Center_X - Width * 4 / 19,
            Center_Y + Height * 3.5 / 28);

      /* Middle segment */             
   DrawLine(Center_X - Width * 4 / 19,
            Center_Y + Height * 3.5 / 28,
            Center_X + Width * 4 / 19,
            Center_Y + Height * 3.5 / 28);

      /* Right segment */             
   DrawLine(Center_X + Width * 4 / 19,
            Center_Y + Height * 3.5 / 28,
            Center_X + Width * 5 / 19,
            Center_Y + Height * 5.5 / 28);
}

/*******************************/
/* drawSpongebobTeeth Function */
/*******************************/
void drawSpongebobTeeth(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* White tooth surface */
   SetPenColorHex(0xFFFFFF);
                            
      /* Left */
   DrawFillBox(Center_X - Width * 1.5 / 19,
               Center_Y + Height * 2.5 / 28,
               Center_X - Width * .5 / 19,
               Center_Y + Height * 3.5 / 28);                           
    
      /* Right */                
   DrawFillBox(Center_X + Width * 1.5 / 19,
               Center_Y + Height * 2.5 / 28,
               Center_X + Width * .5 / 19,
               Center_Y + Height * 3.5 / 28);

   /* Black tooth outline */
   SetPenColorHex(0x000000);
                           
      /* Left */                            
   DrawBox(Center_X - Width * 1.5 / 19,
           Center_Y + Height * 2.5 / 28,
           Center_X - Width * .5 / 19,
           Center_Y + Height * 3.5 / 28);
                        
      /* Right */    
   DrawBox(Center_X + Width * 1.5 / 19,
           Center_Y + Height * 2.5 / 28,
           Center_X + Width * .5 / 19,
           Center_Y + Height * 3.5 / 28); 
}

/*******************************/
/* drawSpongebobShirt Function */
/*******************************/
void drawSpongebobShirt(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* Spongebob's Shirt - White Surface */
   SetPenColorHex(0xFFFFFF);
   
   /* Rectangle */
   DrawFillBox(Center_X - Width * 6.5 / 19,
               Center_Y - Height * 4.5 / 28,
               Center_X + Width * 6.5 / 19,
               Center_Y - Height * 2.5 / 28);
               
   /* Triangles */
   
      /* Left */
   DrawFillTriangle(Center_X - Width * 6.5 / 19,
                    Center_Y - Height * 4.5 / 28,
                    Center_X - Width * 7 / 19,
                    Center_Y - Height * 2.5 / 28,
                    Center_X - Width * 6.5 / 19,
                    Center_Y - Height * 2.5 / 28);

      /* Right */
   DrawFillTriangle(Center_X + Width * 6.5 / 19,
                    Center_Y - Height * 4.5 / 28,
                    Center_X + Width * 7 / 19,
                    Center_Y - Height * 2.5 / 28,
                    Center_X + Width * 6.5 / 19,
                    Center_Y - Height * 2.5 / 28);

   /* Spongebob's Shirt - Lines */
   SetPenColorHex(0x000000);
   
      /* Left */
   DrawLine(Center_X - Width * 6.5 / 19,
            Center_Y - Height * 4.5 / 28,
            Center_X - Width * 41 / 114,
            Center_Y - Height * 2.5 / 28);

      /* Right*/             
   DrawLine(Center_X + Width * 6.5 / 19,
            Center_Y - Height * 4.5 / 28,
            Center_X + Width * 41 / 114,
            Center_Y - Height * 2.5 / 28);
            
   /* Spongebob's Collar - Lines */

      /* Left */
   DrawLine(Center_X - Width * 2.5 / 19,
            Center_Y - Height * 2.5 / 28,
            Center_X - Width * 1 / 19,
            Center_Y - Height * 3.5 / 28);
            
   DrawLine(Center_X - Width * 1 / 19,
            Center_Y - Height * 3.5 / 28,
            Center_X,
            Center_Y - Height * 2.5 / 28);

      /* Right */
   DrawLine(Center_X + Width * 2.5 / 19,
            Center_Y - Height * 2.5 / 28,
            Center_X + Width * 1 / 19,
            Center_Y - Height * 3.5 / 28);
            
   DrawLine(Center_X + Width * 1 / 19,
            Center_Y - Height * 3.5 / 28,
            Center_X,
            Center_Y - Height * 2.5 / 28);
}

/*******************************/
/* drawSpongebobPants Function */
/*******************************/
void drawSpongebobPants(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* Spongebob's Brown Pants */
   SetPenColorHex(0x996600);   

   /* Rectangle */
   DrawFillBox(Center_X - Width * 6 / 19,
               Center_Y - Height * 7.5 / 28,
               Center_X + Width * 6 / 19,
               Center_Y - Height * 4.5 / 28);
               
   /* Triangle */
      
      /* Left */
   DrawFillTriangle(Center_X - Width * 6 / 19,
                    Center_Y - Height * 7.5 / 28,
                    Center_X - Width * 6 / 19,
                    Center_Y - Height * 4.5 / 28,
                    Center_X - Width * 6.5 / 19,
                    Center_Y - Height * 4.5 / 28);

      /* Right */
   DrawFillTriangle(Center_X + Width * 6 / 19,
                    Center_Y - Height * 7.5 / 28,
                    Center_X + Width * 6 / 19,
                    Center_Y - Height * 4.5 / 28,
                    Center_X + Width * 6.5 / 19,
                    Center_Y - Height * 4.5 / 28);

   /* Spongebob's Pant Legs */

   /* Brown pant leg surface */
   SetPenColorHex(0x996600);
   
      /* Left */
   DrawFillBox(Center_X - Width * 4 / 19,
               Center_Y - Height * 8 / 28,
               Center_X - Width * 1 / 19,
               Center_Y - Height * 7.5 / 28);

      /* Right */               
   DrawFillBox(Center_X + Width * 4 / 19,
               Center_Y - Height * 8 / 28,
               Center_X + Width * 1 / 19,
               Center_Y - Height * 7.5 / 28);                    

   /* Black pant leg outline */
   SetPenColorHex(0x000000);
   
      /* Left */
   DrawBox(Center_X - Width * 4 / 19,
           Center_Y - Height * 8 / 28,
           Center_X - Width * 1 / 19,
           Center_Y - Height * 7.5 / 28); 

      /* Right */
   DrawBox(Center_X + Width * 4 / 19,
           Center_Y - Height * 8 / 28,
           Center_X + Width * 1 / 19,
           Center_Y - Height * 7.5 / 28); 
}   

/*******************************/
/* drawSpongebobShoes Function */
/*******************************/
void drawSpongebobShoes(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* Large block - Black */
   SetPenColorHex(0x000000);
      
      /* Left */
   DrawFillBox(Center_X - Width * 3.5 / 19,
               Center_Y - Height * 14 / 28,
               Center_X - Width * 1.5 / 19,
               Center_Y - Height * 12.75 / 28);

      /* Right */
   DrawFillBox(Center_X + Width * 3.5 / 19,
               Center_Y - Height * 14 / 28,
               Center_X + Width * 1.5 / 19,
               Center_Y - Height * 12.75 / 28);

   /* Small block - Black */
   
      /* Left */
   DrawFillBox(Center_X - Width * 4.5 / 19,
               Center_Y - Height * 14 / 28,
               Center_X - Width * 3.5 / 19,
               Center_Y - Height * 13.5 / 28);

      /* Right */               
   DrawFillBox(Center_X + Width * 4.5 / 19,
               Center_Y - Height * 14 / 28,
               Center_X + Width * 3.5 / 19,
               Center_Y - Height * 13.5 / 28);


   /* Circle - Black */
   
      /* Left */
   DrawFillCircle(Center_X - Width * 4 / 19,
                  Center_Y - Height * 13 / 28,
                  Width * .75 / 19);

      /* Right */               
   DrawFillCircle(Center_X + Width * 4 / 19,
                  Center_Y - Height * 13 / 28,
                  Width * .75 / 19);
}

/******************************/
/* drawSpongebobLegs Function */
/******************************/
void drawSpongebobLegs(double Center_X, double Center_Y, double Height, unsigned long SkinColor)
{
   double Width = Height * 19 / 28;     
   SetPenColorHex(SkinColor);
   
      /* Left */
   DrawFillBox(Center_X - Width * 3 / 19,
               Center_Y - Height * 10.5 / 28,
               Center_X - Width * 2 / 19,
               Center_Y - Height * 8 / 28); 

      /* Right */
   DrawFillBox(Center_X + Width * 3 / 19,
               Center_Y - Height * 10.5 / 28,
               Center_X + Width * 2 / 19,
               Center_Y - Height * 8 / 28);  
}

/*******************************/
/* drawSpongebobSocks Function */
/*******************************/
void drawSpongebobSocks(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* Sock top */
   SetPenColorHex(0x000000);

      /* Left */                   
   DrawLine(Center_X - Width * 3 / 19,
            Center_Y - Height * 8 / 28,
            Center_X - Width * 2 / 19,
            Center_Y - Height * 8 / 28);  

      /* Right */
   DrawLine(Center_X + Width * 3 / 19,
            Center_Y - Height * 8 / 28,
            Center_X + Width * 2 / 19,
            Center_Y - Height * 8/28); 

   /* Sock surface - White */                             
   SetPenColorHex(0xFFFFFF);
    
      /* Left */
   DrawFillBox(Center_X - Width * 3 / 19,
               Center_Y - Height * 13 / 28,
               Center_X - Width * 2 / 19,
               Center_Y - Height * 10.5 / 28);                                    

      /* Right */
   DrawFillBox(Center_X + Width * 3 / 19,
               Center_Y - Height * 13 / 28,
               Center_X + Width * 2 / 19,
               Center_Y - Height * 10.5 / 28);               

   /* Sock outline - Left Leg */
   SetPenColorHex(0x000000);

      /* Left */
   DrawLine(Center_X - Width * 3 / 19,
            Center_Y - Height * 13 / 28,
            Center_X - Width * 3 / 19,
            Center_Y - Height * 10.5 / 28);
            
      /* Right */
   DrawLine(Center_X - Width * 2 / 19,
            Center_Y - Height * 13 / 28,
            Center_X - Width * 2 / 19,
            Center_Y - Height * 10.5 / 28);

      /* Top */         
   DrawLine(Center_X - Width * 3 / 19,
            Center_Y - Height * 10.5 / 28,
            Center_X - Width * 2 / 19,
            Center_Y - Height * 10.5 / 28);             

   /* Sock outline - Right Leg */
    
      /* Left */             
   DrawLine(Center_X + Width * 2 / 19,
            Center_Y - Height * 13 / 28,
            Center_X + Width * 2 / 19,
            Center_Y - Height * 10.5 / 28);    

      /* Right */
   DrawLine(Center_X + Width * 3 / 19,
            Center_Y - Height * 13 / 28,
            Center_X + Width * 3 / 19,
            Center_Y - Height * 10.5 / 28);

   /* Top */
   DrawLine(Center_X + Width * 3 / 19,
            Center_Y - Height * 10.5 / 28,
            Center_X + Width * 2 / 19,
            Center_Y - Height * 10.5 / 28); 
}

/*****************************/
/* drawSpongebobTie Function */
/*****************************/
void drawSpongebobTie(double Center_X, double Center_Y, double Height)
{
   double Width = Height * 19 / 28;     
   /* Spongebob's Tie - Knot */
   SetPenColorHex(0xCC3333);
   
      /* Left */
   DrawFillTriangle(Center_X - Width * .5 / 19,
                    Center_Y - Height * 3 / 28,
                    Center_X,
                    Center_Y - Height * 2.5 / 28,
                    Center_X,
                    Center_Y - Height * 3.5 / 28);
      /* Right */
   DrawFillTriangle(Center_X + Width * .5 / 19,
                    Center_Y - Height * 3 / 28,
                    Center_X,
                    Center_Y - Height * 2.5 / 28,
                    Center_X,
                    Center_Y - Height * 3.5 / 28);

   /* Spongebob's Tie */
   
      /* Left */
   DrawFillTriangle(Center_X - Width * .5 / 19,
                    Center_Y - Height * 6 / 28,
                    Center_X,
                    Center_Y - Height * 2.5/ 28,
                    Center_X,
                    Center_Y - Height * 6.5 / 28);

      /* Right */
   DrawFillTriangle(Center_X + Width * .5 / 19,
                    Center_Y - Height * 6 / 28,
                    Center_X,
                    Center_Y - Height * 2.5 / 28,
                    Center_X,
                    Center_Y - Height * 6.5 / 28);   
}
