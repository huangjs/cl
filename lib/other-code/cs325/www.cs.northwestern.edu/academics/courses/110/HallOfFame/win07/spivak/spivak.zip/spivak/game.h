#define DIR_LEFT -1
#define DIR_RIGHT 1
#define DIR_DOWN -1
#define DIR_UP 1

/***********************************/
   /* Shape-drawing functions */

void drawObjects(void);

      /* Spongebob Squarepants */
void drawSpongebobs(int index);
void drawSpongebob(double Center_X, double Center_Y, double Height, unsigned long SkinColor);

void drawSpongebobArms(double Center_X, double Center_Y, double Height, unsigned long SkinColor);
void drawSpongebobSleeves(double Center_X, double Center_Y, double Height);
void drawSpongebobEyes(double Center_X, double Center_Y, double Height);
void drawSpongebobTop(double Center_X, double Center_Y, double Height, unsigned long SkinColor);
void drawSpongebobLips(double Center_X, double Center_Y, double Height);
void drawSpongebobTeeth(double Center_X, double Center_Y, double Height);
void drawSpongebobShirt(double Center_X, double Center_Y, double Height);
void drawSpongebobPants(double Center_X, double Center_Y, double Height);
void drawSpongebobShoes(double Center_X, double Center_Y, double Height);
void drawSpongebobLegs(double Center_X, double Center_Y, double Height, unsigned long SkinColor);
void drawSpongebobSocks(double Center_X, double Center_Y, double Height);
void drawSpongebobTie(double Center_X, double Center_Y, double Height);

      /* Bubbles */
void drawBubbles(int index);
void drawBubble(double Center_X, double Center_Y, double Radius, unsigned long Bubble_Color);
/***********************************/

/***********************************/
   /* Initializing functions */

      /* Spongebob Squarepants */
void initializeSpongebobs(void);
void initializeSpongebob(int index);

      /* Bubbles */
void initializeBubbles(void);
void initializeBubble(int index);
/***********************************/

/***********************************/
   /* Graphics and animation functions */
void drawObjects(void);
void moveSpongebobs(void);
void bounceSpongebob(OBJECT *spongebob);
void bounceSpongebob_X(OBJECT *spongebob);
void bounceSpongebob_Y(OBJECT *spongebob);
void angrySpongebob(void);  
/***********************************/

/***********************************/
   /* Interactive functions */
int firstClick(void);
int secondClick(void);
int thirdClick(void); 
void keyLeft(OBJECT *pickobject);
void keyRight(OBJECT *pickobject);
void keyUp(OBJECT *pickobject);
void keyDown(OBJECT *pickobject);
/***********************************/

/***********************************/
   /* Utility functions */
void gameGreeting(void);   
int pickRandomInt(int low, int high);
unsigned long pickRandomRGB(void);
/***********************************/
