/* * * * * * * * * * * * * * * * * * * * * * * * * *
 * Problem Assignment 5.2 - Spongebob Squarepants  *
 *                     Animator                    *
 *           Dmitry Spivak, 03.12.2007             *
 *                   EECS 110-0                    *
 * A program that draws pictures of randomly       *
 * moving (and sized, and colored) Spongebob       *
 * Squarepantses as well as randomly sized and     *
 * placed stationary blue-green bubbles behind     *
 * them. It also lets you change sizes, colors,    *
 * and even access an easter egg or two...         *
 * * * * * * * * * * * * * * * * * * * * * * * * * */

typedef enum
{
SPONGEBOB_TYPE,
BUBBLE_TYPE
} OBJECT_TYPE;

typedef struct
{
OBJECT_TYPE type;
double x_pos;
double y_pos;
double size;
double speed;
int dir_x;
int dir_y;
unsigned long color;
} OBJECT;

#include "introGlutLib.h"		//include the basic drawing library
#include "game.h"             // for necessary game prototypes
#include <time.h>				
#include <stdlib.h>				
#include <string.h>	
#include <windows.h>		

#define MIN_SPONGEBOBS 3
#define MAX_SPONGEBOBS 10
#define MIN_SPONGEBOB_SIZE 50
#define MAX_SPONGEBOB_SIZE 150
#define MIN_BUBBLES 20
#define MAX_BUBBLES 30
#define MIN_BUBBLE_SIZE 10
#define MAX_BUBBLE_SIZE 25
#define BACKGROUND_COLOR 0xA8C2D9

OBJECT object[MAX_SPONGEBOBS + MAX_BUBBLES];
int num_objects = 0;

/*****************************************************/


/*******************/
/* main() Function */			
/*******************/
int main(void)
{
   gameGreeting();           
   srand(time(NULL));      
   initializeBubbles();    // determine position of bubbles
   initializeSpongebobs(); // determine position of Spongebobs
    
	InitGraphics();			// start GLUT
	return 0;
}

/******************************/
/* initializeBubbles Function */
/******************************/
void initializeBubbles(void)
{
   num_objects = pickRandomInt(MIN_BUBBLES, MAX_BUBBLES);
   for (int i = 0; i < num_objects; i++)
   {
      initializeBubble(i);
   }
}

/*****************************/
/* initializeBubble Function */
/*****************************/
void initializeBubble(int index)
{
   OBJECT *bubble = &object[index];
   int rad = pickRandomInt(MIN_BUBBLE_SIZE, MAX_BUBBLE_SIZE);
   bubble->type = BUBBLE_TYPE;
   bubble->size = rad;
   bubble->x_pos = pickRandomInt(rad, NU_SCREENWIDTH - rad);
   bubble->y_pos = pickRandomInt(rad, NU_SCREENHEIGHT - rad);
   bubble->color = pickRandomInt(0xA8C2D9,0xA8FFD9);  // ensures that bubbles 
                                                      // are between blue and green.
}
   
/*********************************/
/* initializeSpongebobs Function */
/*********************************/
void initializeSpongebobs(void)
{
   int num_Spongebobs = pickRandomInt(MIN_SPONGEBOBS, MAX_SPONGEBOBS);
   for (int i = num_objects; i < num_objects + num_Spongebobs; i++)
   {
      initializeSpongebob(i);
   }
   num_objects += num_Spongebobs;
}

/********************************/
/* initializeSpongebob Function */
/********************************/
void initializeSpongebob(int index)
{
   OBJECT *spongebob = &object[index];
   int height = pickRandomInt(MIN_SPONGEBOB_SIZE, MAX_SPONGEBOB_SIZE);
   double limit = height * 19 / 28;
   spongebob->type = SPONGEBOB_TYPE;
   spongebob->size = height;
   spongebob->x_pos = pickRandomInt( limit / 2, NU_SCREENWIDTH - limit /2);
   spongebob->y_pos = pickRandomInt(height / 2, NU_SCREENHEIGHT - height / 2);
   spongebob->speed = pickRandomInt(2,5) - .005 * height ;
   spongebob->dir_x = pickRandomInt(0,1) ? DIR_LEFT : DIR_RIGHT;
   spongebob->dir_y = pickRandomInt(0,1) ? DIR_UP : DIR_DOWN;
   spongebob->color = pickRandomRGB();
}

/**********************/
/* myDisplay Function */
/**********************/
void myDisplay(void)
{
   SetBackgndColorHex(BACKGROUND_COLOR);
   ClearWindow();
   drawObjects();
   moveSpongebobs();
}

/************************/
/* drawObjects Function */
/************************/
void drawObjects(void)
{
   for (int i = 0; i < num_objects; i++)
   {     
      OBJECT *pObject = &object[i];
      if (pObject->type == BUBBLE_TYPE)
      {
         drawBubbles(i);
      }
      else if (pObject->type == SPONGEBOB_TYPE)
      {
         drawSpongebobs(i); 
      }
   }
}

/************************/
/* drawBubbles Function */
/************************/
void drawBubbles(int index)
{
   OBJECT *bubble = &object[index];
   drawBubble(bubble->x_pos, bubble->y_pos, bubble->size, bubble->color);
}

/***********************/
/* drawBubble Function */
/***********************/
void drawBubble(double Center_X, double Center_Y, double Radius, unsigned long Bubble_Color)
{
   SetPenColorHex(Bubble_Color);
   DrawFillCircle(Center_X, Center_Y, Radius);
   SetPenColorHex(0x000000);
   DrawCircle(Center_X, Center_Y, Radius);
}

/***************************/
/* drawSpongebobs Function */
/***************************/
void drawSpongebobs(int index)
{
   OBJECT *spongebob = &object[index];
   drawSpongebob(spongebob->x_pos, spongebob->y_pos, spongebob->size, spongebob->color);
}

/**************************/
/* drawSpongebob Function */
/**************************/
void drawSpongebob(double Center_X, double Center_Y, double Height, unsigned long SkinColor)
{
   drawSpongebobArms(Center_X, Center_Y, Height, SkinColor);
   drawSpongebobSleeves(Center_X, Center_Y, Height);
   drawSpongebobTop(Center_X, Center_Y, Height, SkinColor);
   drawSpongebobEyes(Center_X, Center_Y, Height);
   drawSpongebobLips(Center_X, Center_Y, Height);
   drawSpongebobTeeth(Center_X, Center_Y, Height);
   drawSpongebobShirt(Center_X, Center_Y, Height);                                    
   drawSpongebobPants(Center_X, Center_Y, Height);
   drawSpongebobShoes(Center_X, Center_Y, Height);
   drawSpongebobLegs(Center_X, Center_Y, Height, SkinColor);
   drawSpongebobSocks(Center_X, Center_Y, Height);
   drawSpongebobTie(Center_X, Center_Y, Height);                                                    
}

/***************************/
/* moveSpongebobs Function */
/***************************/
void moveSpongebobs(void)
{
   for (int i = 0; i < num_objects; i++)
   {
      OBJECT *spongebob = &object[i];
      if (spongebob->type == SPONGEBOB_TYPE)
      {
         bounceSpongebob(spongebob);
      }
   }
}

/****************************/
/* bounceSpongebob Function */
/****************************/
void bounceSpongebob(OBJECT *spongebob)
{
   bounceSpongebob_X(spongebob);
   bounceSpongebob_Y(spongebob);
}  

/******************************/
/* bounceSpongebob_X Function */
/******************************/   
void bounceSpongebob_X(OBJECT *spongebob)
{
   double limit = spongebob->size * 19 / 28;
   if (spongebob->x_pos < limit / 2 || spongebob->x_pos > NU_SCREENWIDTH -  limit / 2)
   {
      spongebob->dir_x *= -1;
   }
   spongebob->x_pos += spongebob->speed * spongebob->dir_x;
}

/******************************/
/* bounceSpongebob_X Function */
/******************************/   
void bounceSpongebob_Y(OBJECT *spongebob)
{
   if (spongebob->y_pos < (spongebob->size / 2) || spongebob->y_pos > NU_SCREENHEIGHT - (spongebob->size / 2) )
   {
      spongebob->dir_y *= -1;
   }
   spongebob->y_pos += spongebob->speed * spongebob->dir_y; 
}


/***************** Interactive Functions *****************/

/********************/
/* myMouse Function */
/********************/
void myMouse(int button, int state, int x, int y) 
{
   static int clicked = 0; // to avoid modification at each click 
   if (state == GLUT_UP && button == GLUT_RIGHT_BUTTON)
   {
      switch (clicked)
      {
         case 0 : clicked = firstClick(); break;
         case 1 : clicked = secondClick(); break;
         case 2 : clicked = thirdClick(); break;
         default : ;
      }
   }     
}

/***********************/
/* firstClick Function */
/***********************/
int firstClick(void)
{
   MessageBox(NULL,
              "Thanks for clicking, but this program\n"
              "doesn't handle right-clicks. Please don't\n"
              "do it again...", 
              "Oops!", MB_OK);
   return 1;
}  

/************************/
/* secondClick Function */
/************************/
int secondClick(void)
{
   MessageBox(NULL,
              "I specifically asked you not to do that.\n"
              "Don't test me, man; I've had a rough day.\n",
              "... stop it...",
              MB_OK);    
   return 2;
}

/***********************/
/* thirdClick Function */
/***********************/
int thirdClick(void)
{
   MessageBox(NULL,
              "NO MORE MISTER NICE SQUAREPANTS!",
              ">:o",
              MB_OK);
   angrySpongebob(); // makes all Spongebobs turn black
   return 3;   
}

/***************************/
/* angrySpongebob Function */
/***************************/
void angrySpongebob(void)
{
   for (int i = 0; i < num_objects; i++)
   {
      OBJECT *spongebob = &object[i];
      if (spongebob->type == SPONGEBOB_TYPE)
      {
         spongebob->color = 0;
      }
   }      
}

/***********************/
/* myKeyboard Function */
/***********************/
void myKeyboard(unsigned char key, int x, int y){}

/***************************/
/*  mySpecialKey Function  */
/***************************/
void mySpecialKey(int key, int x, int y)
{
OBJECT *pickobject = &object[pickRandomInt(0, num_objects - 1)];

   if (key == GLUT_KEY_LEFT)
   {
      keyLeft(pickobject);
   }   
   
	if (key == GLUT_KEY_RIGHT)
	{
      keyRight(pickobject);
   }   
   
   if (key == GLUT_KEY_UP)
   {
       keyUp(pickobject);  
   }   

   if (key == GLUT_KEY_DOWN)
   {
       keyDown(pickobject);
   }   
   if (key == GLUT_KEY_END)
   {
      exit(0);
   }
}

/********************/
/* keyLeft Function */
/********************/
void keyLeft(OBJECT *pickobject)
{
   while (pickobject->type != SPONGEBOB_TYPE)
   {
   pickobject = &object[pickRandomInt(0, num_objects - 1)];
   }
   pickobject->color = pickRandomRGB();
}     

/*********************/
/* keyRight Function */
/*********************/
void keyRight (OBJECT *pickobject)
{
   while (pickobject->type != BUBBLE_TYPE)
   {
   pickobject = &object[pickRandomInt(0, num_objects - 1)];
   }
   pickobject->color = pickRandomInt(0xA8C2D9,0xA8FFD9);
}

/******************/
/* keyUp Function */
/******************/
void keyUp (OBJECT *pickobject)
{
   while (pickobject->type != SPONGEBOB_TYPE)
   {
   pickobject = &object[pickRandomInt(0, num_objects - 1)];
   }
   
   if (pickobject->size < 250)
   {
      pickobject->size = pickobject->size + 5;
   }
   else
   {
      MessageBox(NULL, 
      "One of your Spongebobs is too big and \n"
      "might get stuck! Press the down key\n"
      "to make him small again.", 
      "Oops!", 
      MB_OK);
   } 
}

/********************/
/* keyDown Function */
/********************/
void keyDown (OBJECT *pickobject)
{
   while (pickobject->type != SPONGEBOB_TYPE)
   {
      pickobject = &object[pickRandomInt(0, num_objects - 1)];
   }
   if (pickobject->size > 40)
   {
      pickobject->size = pickobject->size - 5;
   }
   else
   {
      MessageBox(NULL, 
      "One of your Spongebobs is too small!\n"
      "Press the up key to make him big again.", 
      "Oops!", 
      MB_OK);
   }
}


/***************** Utility Functions *****************/

/*************************/
/* gameGreeting Function */
/*************************/
void gameGreeting(void)
{
MessageBox(NULL,
           "Welcome to the Spongebob Squarepants Animator!\n\n"
           "The purpose of this simple, interactive animation is to \n"
           "demonstrate one type of application that can be written \n"
           "with the OpenGL Utility Toolkit.\n\n"
           "*******************************************\n"
           "SPONGEBOB ANIMATOR CONTROLS:\n\n"
           "- Left Arrow: Change Spongebob's colors\n"
           "- Right Arrow: Change bubble's colors\n"
           "- Up Arrow: Make Spongebob larger\n"
           "- Down Arrow: Make Spongebob smaller\n"
           "- End: Exit the program\n\n\n"
           "... and don't right-click. Seriously.",
           "Welcome!",
           MB_OK);
}

/**************************/
/* pickRandomInt Function */
/**************************/
int pickRandomInt(int min, int max)
{
    return min + rand() % (max - min + 1);
} 

/**************************/
/* pickRandomRGB Function */
/**************************/
unsigned long pickRandomRGB()
{
    int red = rand() % 255;
    int green = rand() % 255;
    int blue = rand() % 255;
    return red * 256 * 256 + green * 256 + blue;
} 

/***************** Shape-Drawing Functions *****************/
// found in drawingFunctions.c to preserve readability     //

