Changes to make xmlutils work, given acl-compat in portable aserve.

In acl-excl-cmu.lisp, acl-excl-lw.lisp, and acl-excl-mcl.lisp:

Add
    "*DRIBBLE-BUG-HOOKS*"
to the export list.

Add
(defvar *dribble-bug-hooks* nil)
to the code

This is needed by the XML parser.


In phtml.cl and pxml0.cl:

Add
  (:import-from #+allego #:mp #-allegro #:acl-compat-mp #:without-scheduling)
to the defpackage.

In phtml.cl and pxml1.cl:

Replace all occurrences of 
  mp::without-scheduling 
with 
  without-scheduling.


In pxml0.cl, add

(defun name= (sym1 sym2)
  (string= (string sym1) (string sym2)))

In pxml1.cl and pxml2.cl:

Replace all occurrences of (string= (symbol-name ...) "...") (either order)
with (name= ... '#:...). 

Replace both occurrences of (string= ... "xmlns" :end1 5) with
(string-equal ... '#:xmlns :endl 5).

This is to get around the case differences between Franz Modern and ANSI
Common Lisp.
